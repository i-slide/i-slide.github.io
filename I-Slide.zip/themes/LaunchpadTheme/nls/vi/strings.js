define({
  "_themeLabel": "Chủ đề Bệ phóng",
  "_layout_default": "Bố cục mặc định",
  "_layout_right": "Bố cục bên phải"
});