define({
  "_themeLabel": "Teema Launchpad",
  "_layout_default": "Vaikimisi paigutus",
  "_layout_right": "Parempoolne paigutus"
});