define({
  "_widgetLabel": "Dockningsfältshanteraren",
  "_layout_default": "Standardlayout",
  "_layout_layout1": "Layout 0",
  "more": "Fler widgetar"
});