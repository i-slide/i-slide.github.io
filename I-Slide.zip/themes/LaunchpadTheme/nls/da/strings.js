define({
  "_themeLabel": "Launchpad-tema",
  "_layout_default": "Standardlayout",
  "_layout_right": "Højre-layout"
});