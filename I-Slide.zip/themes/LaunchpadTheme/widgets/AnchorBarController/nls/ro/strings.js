define({
  "_widgetLabel": "Controller bară ancorare",
  "_layout_default": "Aspect implicit",
  "_layout_layout1": "Aspectul 0",
  "more": "Mai multe widgeturi"
});